self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "baa5a67b53009c3d033f0167afa565d7",
    "url": "/resume/index.html"
  },
  {
    "revision": "8aae3981b8bdfee68929",
    "url": "/resume/static/css/main.ef300678.chunk.css"
  },
  {
    "revision": "e4aaec95771354b372d5",
    "url": "/resume/static/js/2.6737e60f.chunk.js"
  },
  {
    "revision": "9b318b6fb13190fe82c0677e9264b3c7",
    "url": "/resume/static/js/2.6737e60f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8aae3981b8bdfee68929",
    "url": "/resume/static/js/main.039198fe.chunk.js"
  },
  {
    "revision": "2b17229f8e36d952a251",
    "url": "/resume/static/js/runtime-main.6275bf14.js"
  },
  {
    "revision": "25d8cff6a285b07eb5571f03e2a1edb9",
    "url": "/resume/static/media/ags-pc.25d8cff6.jpg"
  },
  {
    "revision": "f5711eaa4996e1483f221e7c57cb7905",
    "url": "/resume/static/media/algo.f5711eaa.svg"
  },
  {
    "revision": "9986fcc67e0d5801014ae4d800f20199",
    "url": "/resume/static/media/amann-pc.9986fcc6.jpg"
  },
  {
    "revision": "63f68ccc85cc2ab7da913353c08cccaf",
    "url": "/resume/static/media/api.63f68ccc.svg"
  },
  {
    "revision": "a42040d5c68d4d3fed9b27878d2fcca5",
    "url": "/resume/static/media/backend.a42040d5.svg"
  },
  {
    "revision": "3b779989f29d01367d2b579b4a351253",
    "url": "/resume/static/media/bday-2.3b779989.jpg"
  },
  {
    "revision": "f7a80236ceff9e9e7efbb77fdcbce447",
    "url": "/resume/static/media/blog-pc.f7a80236.jpg"
  },
  {
    "revision": "92c2a70a27e410c0038c52de93ac6831",
    "url": "/resume/static/media/bonopoly.92c2a70a.jpg"
  },
  {
    "revision": "6ccc8d6ed04754052b4c2145eb626175",
    "url": "/resume/static/media/bootstrap.6ccc8d6e.svg"
  },
  {
    "revision": "5c974cee2a14107a26cd87b8262e0677",
    "url": "/resume/static/media/django.5c974cee.svg"
  },
  {
    "revision": "0d1f1296a2388b51281a6730ab16c5e5",
    "url": "/resume/static/media/eathealthy-pc.0d1f1296.jpg"
  },
  {
    "revision": "0b4aa2ca117c06c76c09095636b21e13",
    "url": "/resume/static/media/eoh-pc.0b4aa2ca.jpg"
  },
  {
    "revision": "00ce48b9805589b405abe97344e9586f",
    "url": "/resume/static/media/ewb-pc.00ce48b9.jpg"
  },
  {
    "revision": "7cfd86a32c60e684bf1add70f0958921",
    "url": "/resume/static/media/figma.7cfd86a3.svg"
  },
  {
    "revision": "cbc38ef18c5a6ecdc0ace14b23e84380",
    "url": "/resume/static/media/github.cbc38ef1.svg"
  },
  {
    "revision": "c827969e84a3cef05c420fc24fb370ed",
    "url": "/resume/static/media/harsh-pc.c827969e.jpg"
  },
  {
    "revision": "cf101b1752e7506265f7bc440b7fef78",
    "url": "/resume/static/media/html-5.cf101b17.svg"
  },
  {
    "revision": "2ea3f45f99bc1cdf30bbd8b95e635b30",
    "url": "/resume/static/media/illustrator.2ea3f45f.svg"
  },
  {
    "revision": "a13311a36cde2cfa79bff078a24103bf",
    "url": "/resume/static/media/image_illustration.a13311a3.svg"
  },
  {
    "revision": "1f28e777d014b71d2e0e911aefc95fa0",
    "url": "/resume/static/media/indicon.1f28e777.jpg"
  },
  {
    "revision": "3531f9fdf9d28c70c55d59aa03252ffe",
    "url": "/resume/static/media/javascript.3531f9fd.svg"
  },
  {
    "revision": "54904a36f1402ca9c216f35e3084b87e",
    "url": "/resume/static/media/khushi-pc.54904a36.jpg"
  },
  {
    "revision": "62492e1ca9c8fae69f9a4d345186d905",
    "url": "/resume/static/media/mask-pc.62492e1c.jpg"
  },
  {
    "revision": "e65bf0382f66f4a6ca3bd9e029afc549",
    "url": "/resume/static/media/minify-pv.e65bf038.jpg"
  },
  {
    "revision": "5d5252ad5d4bbe8959c0f7c2c0ca8dc7",
    "url": "/resume/static/media/node-js.5d5252ad.svg"
  },
  {
    "revision": "3c0cfe6073abce1debbdb0333884a748",
    "url": "/resume/static/media/photoshop.3c0cfe60.svg"
  },
  {
    "revision": "64c56c72135ba0b4ddf8da186182b723",
    "url": "/resume/static/media/pin.64c56c72.svg"
  },
  {
    "revision": "2ffd1fd9c6ed69bdde93e4dca5433cc5",
    "url": "/resume/static/media/portfolio.2ffd1fd9.jpg"
  },
  {
    "revision": "abd7ee95fb9290ea7b0421c3398182fa",
    "url": "/resume/static/media/print.abd7ee95.jpg"
  },
  {
    "revision": "b5fac2be7a6a8edc808f550a24217391",
    "url": "/resume/static/media/puzzle.b5fac2be.svg"
  },
  {
    "revision": "ab5da407e156a403063b5005121aeb1a",
    "url": "/resume/static/media/python.ab5da407.svg"
  },
  {
    "revision": "516ea315588fa9638826b58a739ab842",
    "url": "/resume/static/media/react.516ea315.svg"
  },
  {
    "revision": "1464053c658e62318c689e56c4f1643c",
    "url": "/resume/static/media/repair.1464053c.svg"
  },
  {
    "revision": "0a65f39fa2f313dba7757dea3105a7a5",
    "url": "/resume/static/media/resume.0a65f39f.pdf"
  },
  {
    "revision": "4a04f9f0dd3f59df96497cc7c3021550",
    "url": "/resume/static/media/tie.4a04f9f0.svg"
  },
  {
    "revision": "b46710ff8fbdb68ffa5cb5fdbf26c419",
    "url": "/resume/static/media/ux.b46710ff.svg"
  },
  {
    "revision": "844f17d0225e733ddd84e8c34de613ba",
    "url": "/resume/static/media/wordpress.844f17d0.svg"
  }
]);